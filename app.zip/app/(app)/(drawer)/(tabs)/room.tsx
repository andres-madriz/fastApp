import React from 'react';
import { View, Text } from 'react-native';

export default function RoomScreen() {
  return (
    <View style={{ alignItems: 'center', flex: 1, justifyContent: 'center' }}>
      <Text style={{ fontSize: 24 }}>Room</Text>
    </View>
  );
}
